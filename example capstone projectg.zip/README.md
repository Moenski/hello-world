﻿# IBM Capstone
Final Project for the IBM Data Science Professional Certificate.  
Email me at carlos.restrepo@live.ca with any questions or comments.
  
The map outputs are ommited as they stop the notebook from displaying on the github website. These maps are shown in the report.
